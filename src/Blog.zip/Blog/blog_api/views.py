from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Blog
from .serializers import BlogSerializer

class BlogListCreate(generics.ListCreateAPIView):
    queryset = Blog.objects.all()
    serializer_class = BlogSerializer

class BlogRetrieveUpdateDestroy(generics.RetrieveUpdateDestroyAPIView):
    queryset = Blog.objects.all()
    serializer_class = BlogSerializer

class PairFinding(APIView):
    def post(self, request):
        nums = request.data.get('nums', [])
        target = request.data.get('target', 0)
        pair = self.find_pair(nums, target)
        if pair:
            return Response({"pair": pair})
        else:
            return Response({"message": "Pair not found"})

    @staticmethod
    def find_pair(nums, target):
        seen = set()
        for num in nums:
            complement = target - num
            if complement in seen:
                return [num, complement]
            seen.add(num)
        return None
